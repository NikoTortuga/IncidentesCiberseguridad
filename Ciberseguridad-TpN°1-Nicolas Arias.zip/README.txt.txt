- ¿Por qué el endpoint /vulnerable/{id} representa un fallo IDOR?
 El fallo se encuentra en que no se verifique que el usuario que hace lo solicitud sino
la id de la factura. Esto hace que solamente cambian al id se pueda acceder a la factura 
de otro usuario

- ¿Cómo resuelve el problema el endpoint /secure/{id}?
Se resuelve comparando el username con el valor del usarname de la solicitud
Se da la factura solamente si coinciden. 

- Instrucciones para ejecutar la aplicación y correr las pruebas JSON.
 Se debe ejecutar el proyecto, comprobar si esta corriendo en el localhost, 
luego se debe abrir postman, importar la colección .json y ejecutar la colección. 