# Demostración OWASP A01: Broken Access Control (IDOR)

Proyecto educativo desarrollado con **Spring Boot 3** y **Java 17** para ilustrar de forma práctica la vulnerabilidad **IDOR** (*Insecure Direct Object Reference* / Referencia Directa Insegura a Objetos) y cómo implementarla de manera segura.

---

## 🎯 ¿Cómo funciona?

En la base de datos se cargan inicialmente dos facturas mediante [src/main/resources/data.sql](src/main/resources/data.sql):

- **Factura #1**: Pertenece al usuario `eri_dev` (Monto: $150.000).
- **Factura #2**: Pertenece al usuario `jorge_user` (Monto: $85.000).

La aplicación expone dos endpoints principales:

1. **Endpoint Vulnerable (`/api/invoices/vulnerable/{id}`)**:

   - Devuelve la factura solicitada por ID sin verificar si el usuario solicitante (`X-User-Name`) es el dueño.
   - **Falla de seguridad**: Un usuario como `jorge_user` puede ver la factura #1 de `eri_dev` simplemente cambiando el ID en la URL.
2. **Endpoint Seguro (`/api/invoices/secure/{id}`)**:

   - Valida en la capa de servicio que el usuario que realiza la petición coincida con el campo `ownerUsername` de la factura.
   - Si no coincide, rechaza la solicitud retornando un error **HTTP 403 Forbidden**.

---

## 📋 Requisitos Previos

- **Java 17** o superior instalado.
- **Maven** instalado (o soporte Maven en tu IDE).
- **MySQL Server** en ejecución:
  - Base de datos por defecto: `invoicedb` (se crea automáticamente si no existe).
  - Usuario por defecto: `root`
  - Contraseña por defecto: `1234`
  - *(Puedes modificar estas credenciales en [src/main/resources/application.properties](src/main/resources/application.properties))*.

---

## 🚀 Forma de Ejecutar

### 1. Configurar la base de datos (si es necesario)

Asegúrate de que MySQL esté corriendo en `localhost:3306`. Si tus credenciales son diferentes, ajústalas en [src/main/resources/application.properties](src/main/resources/application.properties):

```properties
spring.datasource.url=jdbc:mysql://localhost:3306/invoicedb?createDatabaseIfNotExist=true&useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC
spring.datasource.username=root
spring.datasource.password=TU_PASSWORD
```

### 2. Iniciar la aplicación

Abre una terminal en la raíz del proyecto y ejecuta:

```bash
mvn spring-boot:run
```

O compila y ejecuta el `.jar`:

```bash
mvn clean package
java -jar target/demo-0.0.1-SNAPSHOT.jar
```

---

## 🧪 Cómo Probar la Aplicación

### Opción A: Desde el Navegador Web (Recomendado)

Abre tu navegador e ingresa a:
👉 [http://localhost:8080](http://localhost:8080)

La aplicación incluye un panel interactivo ([src/main/resources/static/index.html](src/main/resources/static/index.html)) que te permite simular ser `eri_dev` o `jorge_user` y probar ambos endpoints con un solo clic.

---

### Opción B: Mediante cURL o Postman

#### 🔴 1. Probar Endpoint Vulnerable (IDOR)

Simulamos ser `jorge_user` intentando leer la factura 1 (de `eri_dev`):

```bash
curl -X GET http://localhost:8080/api/invoices/vulnerable/1 -H "X-User-Name: jorge_user"
```

**Resultado**: Devuelve los datos de la factura 1 con éxito (Falla de acceso).

---

#### 🛡️ 2. Probar Endpoint Seguro

Simulamos ser `jorge_user` intentando leer la factura 1 a través del endpoint protegido:

```bash
curl -X GET http://localhost:8080/api/invoices/secure/1 -H "X-User-Name: jorge_user"
```

**Resultado**: `HTTP 403 Forbidden` (Acceso denegado: no eres el propietario de esta factura).
