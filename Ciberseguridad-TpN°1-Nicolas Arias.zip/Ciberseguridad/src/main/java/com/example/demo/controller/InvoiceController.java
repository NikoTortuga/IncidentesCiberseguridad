package com.example.demo.controller;

import com.example.demo.entity.Invoice;
import com.example.demo.service.InvoiceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/invoices")
public class InvoiceController {

    @Autowired
    private InvoiceService invoiceService;

     // VULNERABLE (OWASP A01:2025 - IDOR)
     // Falta de verificación de propiedad
     // El parámetro 'currentUser' se recibe en el encabezado, pero no se debe utilizar para validar 
     // si el usuario autenticado tiene permisos sobre el recurso solicitado ('id').
     // Permite que cualquier usuario acceda a facturas ajenas cambian el id de la url
   
    @GetMapping("/vulnerable/{id}")
    public ResponseEntity<Invoice> getVulnerable(
            @PathVariable Long id,
            @RequestHeader(value = "X-User-Name", defaultValue = "guest") String currentUser) {
        
        return ResponseEntity.ok(invoiceService.getInvoiceByIdUnsafe(id));
    }

    // MITIGACIÓN:
    // Implementa control de acceso a nivel de objeto.
    // Se pasa la identidad del usuario ('currentUser') al servicio para validar que el recurso 
    // pertenezca explícitamente a quien lo solicita antes de retornar los datos.
    // Si la validación falla, la capa de servicio arroja una excepción de acceso denegado
    // que responde HTTP 403.
    

    @GetMapping("/secure/{id}")
    public ResponseEntity<Invoice> getSecure(
            @PathVariable Long id,
            @RequestHeader(value = "X-User-Name", defaultValue = "guest") String currentUser) {

        return ResponseEntity.ok(invoiceService.getInvoiceByIdSecure(id, currentUser));
    }
}
