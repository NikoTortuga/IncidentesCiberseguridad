package com.example.demo.repository;

import com.example.demo.entity.Invoice;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface InvoiceRepository extends JpaRepository<Invoice, Long> {

    // Método auxiliar para la mitigación a nivel de base de datos
    Optional<Invoice> findByIdAndOwnerUsername(Long id, String ownerUsername);
}
