package com.example.demo;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
public class InvoiceControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Test
    public void testVulnerableEndpointAllowsIDOR() throws Exception {
        // jorge_user intenta acceder a la factura #1 perteneciente a eri_dev
        mockMvc.perform(get("/api/invoices/vulnerable/1")
                        .header("X-User-Name", "jorge_user"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.ownerUsername").value("eri_dev"))
                .andExpect(jsonPath("$.clientName").value("Empresa Alfa (Coca-Cola Argentina)"));
    }

    @Test
    public void testSecureEndpointDeniesUnauthorizedUser() throws Exception {
        // jorge_user intenta acceder a la factura #1 perteneciente a eri_dev -> 403 Forbidden
        mockMvc.perform(get("/api/invoices/secure/1")
                        .header("X-User-Name", "jorge_user"))
                .andExpect(status().isForbidden());
    }

    @Test
    public void testSecureEndpointAllowsOwner() throws Exception {
        // eri_dev accede legítimamente a su propia factura #1 -> 200 OK
        mockMvc.perform(get("/api/invoices/secure/1")
                        .header("X-User-Name", "eri_dev"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.ownerUsername").value("eri_dev"));
    }
}
