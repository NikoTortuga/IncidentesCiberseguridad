# Proyecto de demostración de incidentes de ciberseguridad OWASP

Este proyecto educativo fue desarrollado en **Spring Boot 3** y **Java 17** para ilustrar tres ejemplos prácticos de vulnerabilidades de seguridad ampliamente conocidas en OWASP:

- **OWASP A01: Broken Access Control (IDOR)**
- **OWASP A02:2025 - Cryptographic Failures**
- **OWASP A03:2025 - Software Supply Chain Failures**

La intención es mostrar, de forma didáctica, el comportamiento vulnerable y la mitigación correspondiente en cada caso, usando endpoints REST que pueden probarse con Postman, curl o directamente desde el navegador.

---

## 1. OWASP A01: Broken Access Control (IDOR)

### Objetivo

Demostrar una falla de control de acceso donde un usuario puede acceder a un recurso ajeno simplemente modificando el identificador del objeto solicitado.

### Caso de uso

En la base de datos se cargan dos facturas desde [src/main/resources/data.sql](src/main/resources/data.sql):

- **Factura #1**: pertenece a `eri_dev`
- **Factura #2**: pertenece a `jorge_user`

### Endpoint vulnerable

**Ruta:** `/api/invoices/vulnerable/{id}`

Este endpoint devuelve la factura solicitada sin verificar si el usuario autenticado es el propietario del recurso.

### Endpoint mitigado

**Ruta:** `/api/invoices/secure/{id}`

Este endpoint valida que el `ownerUsername` de la factura coincida con el usuario que realiza la petición. Si no coincide, responde con **HTTP 403 Forbidden**.

### Ejemplo de prueba

#### 🔴 Probar acceso vulnerable

```bash
curl -X GET http://localhost:8080/api/invoices/vulnerable/1 -H "X-User-Name: jorge_user"
```

**Resultado esperado:** la API responde con la factura #1, aunque no pertenezca a `jorge_user`.

#### 🛡️ Probar acceso mitigado

```bash
curl -X GET http://localhost:8080/api/invoices/secure/1 -H "X-User-Name: jorge_user"
```

**Resultado esperado:** `HTTP 403 Forbidden`.

---

## 2. OWASP A02:2025 - Cryptographic Failures

### Objetivo

Demostrar cómo una API puede exponer información sensible cuando devuelve entidades completas sin excluir campos confidenciales como `password` o `secretApiKey`.

### Endpoint vulnerable

**Ruta:** `/api/users/vulnerable/{id}`

Este endpoint devuelve la entidad completa del usuario, incluyendo información sensible.

### Endpoint mitigado

**Ruta:** `/api/users/mitigated/{id}`

Este endpoint utiliza un DTO público para devolver solo datos seguros, sin incluir credenciales ni secretos.

### Ejemplo de prueba

#### 🔴 Endpoint vulnerable

```bash
curl -X GET http://localhost:8080/api/users/vulnerable/1
```

**Resultado esperado:** la respuesta incluye información sensible como `password` y `secretApiKey`.

#### 🛡️ Endpoint mitigado

```bash
curl -X GET http://localhost:8080/api/users/mitigated/1
```

**Resultado esperado:** la respuesta contiene solo datos no sensibles, como `id`, `username`, `email` y `role`.

---

## 3. OWASP A03:2025 - Software Supply Chain Failures

### Objetivo

Mostrar una falla en la cadena de suministro de software en la que un artefacto se acepta sin verificar:

- el proveedor,
- el origen del artefacto,
- la integridad del archivo mediante SHA-256.

### Endpoint vulnerable

**Ruta:** `/api/components/vulnerable`

Este endpoint acepta un componente sin validar el proveedor ni la integridad del archivo.

### Endpoint mitigado

**Ruta:** `/api/components/mitigated`

Este endpoint valida:

- lista blanca de proveedores,
- dominio autorizado,
- coincidencia estricta del SHA-256.

Si cualquiera de estas comprobaciones falla, la petición se rechaza con **HTTP 400 Bad Request**.

### Ejemplo de prueba

#### 🔴 Probar ingestión vulnerable

```http
POST http://localhost:8080/api/components/vulnerable
Content-Type: application/json
```

```json
{
  "name": "openssl",
  "version": "3.2.0",
  "supplier": "evil-registry",
  "sourceUrl": "https://evil.example.net/download/openssl.tgz",
  "sha256": "abc123",
  "expectedSha256": "def456"
}
```

**Resultado esperado:** la API responde con `200 OK` aunque el componente no haya sido validado.

#### 🛡️ Probar ingestión mitigada

```http
POST http://localhost:8080/api/components/mitigated
Content-Type: application/json
```

```json
{
  "name": "openssl",
  "version": "3.2.0",
  "supplier": "acme",
  "sourceUrl": "https://repo.example.com/artifacts/openssl-3.2.0.tgz",
  "sha256": "a1b2c3d4e5f6",
  "expectedSha256": "a1b2c3d4e5f6"
}
```

**Resultado esperado:** la API responde con `200 OK` si el proveedor, el origen y el hash son válidos.

#### Rechazo de una entrada no confiable

```json
{
  "name": "openssl",
  "version": "3.2.0",
  "supplier": "evil-registry",
  "sourceUrl": "https://evil.example.net/download/openssl.tgz",
  "sha256": "abc123",
  "expectedSha256": "abc123"
}
```

**Resultado esperado:** `400 Bad Request`.

### Endpoints auxiliares

- `GET /api/components` → lista los componentes registrados.
- `DELETE /api/components` → limpia la base de datos de la demostración.

---

## Requisitos previos

- **Java 17** o superior
- **Maven** instalado
- **MySQL Server** en ejecución
  - Base de datos por defecto: `invoicedb`
  - Usuario: `root`
  - Contraseña: `1234`
  - Ajustar configuración en [src/main/resources/application.properties](src/main/resources/application.properties)

---

## Ejecución

### 1. Configurar la base de datos

Ejemplo de configuración:

```properties
spring.datasource.url=jdbc:mysql://localhost:3306/invoicedb?createDatabaseIfNotExist=true&useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC
spring.datasource.username=root
spring.datasource.password=1234
```

### 2. Iniciar la aplicación

```bash
mvn spring-boot:run
```

O compilar y ejecutar el JAR:

```bash
mvn clean package
java -jar target/demo-0.0.1-SNAPSHOT.jar
```

---

## Verificación del proyecto

Se ejecutó la suite de pruebas de la aplicación con Maven para confirmar que la demo sigue funcionando correctamente:

- **Tests ejecutados:** 3
- **Fallos:** 0
- **Errores:** 0

La evidencia de ejecución se encuentra en:

- [target/surefire-reports/com.example.demo.SoftwareSupplyChainControllerTest.txt](target/surefire-reports/com.example.demo.SoftwareSupplyChainControllerTest.txt)

Este proyecto mantiene la estructura didáctica esperada para una presentación académica, separando claramente cada OWASP y mostrando tanto el comportamiento vulnerable como la mitigación aplicada.

---

## Conclusión

El proyecto cumple con una presentación clara y ordenada de los casos:

- **A01**: acceso no autorizado a recursos por ID,
- **A02**: exposición de secretos y credenciales,
- **A03**: ingesta insegura de componentes con validación insuficiente.

Esto lo convierte en una demostración útil para explicar incidentes de ciberseguridad y las buenas prácticas asociadas a cada vulnerabilidad.
