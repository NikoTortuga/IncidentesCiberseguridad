package com.example.demo;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
class UserControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Test
    void vulnerableEndpointExposesSensitiveFields() throws Exception {
        mockMvc.perform(get("/api/users/vulnerable/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.password").value("$2a$10$educational-hash-only"))
                .andExpect(jsonPath("$.secretApiKey").value("sk-demo-eri-123"));
    }

    @Test
    void mitigatedEndpointDoesNotExposeSensitiveFields() throws Exception {
        mockMvc.perform(get("/api/users/mitigated/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.username").value("eri_dev"))
                .andExpect(jsonPath("$.password").doesNotExist())
                .andExpect(jsonPath("$.secretApiKey").doesNotExist());
    }

    @Test
    void mitigatedEndpointReturnsCleanNotFoundError() throws Exception {
        mockMvc.perform(get("/api/users/mitigated/999"))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.title").value("Usuario no encontrado"))
                .andExpect(content().string(org.hamcrest.Matchers.not(
                        org.hamcrest.Matchers.containsString("stackTrace"))));
    }
}