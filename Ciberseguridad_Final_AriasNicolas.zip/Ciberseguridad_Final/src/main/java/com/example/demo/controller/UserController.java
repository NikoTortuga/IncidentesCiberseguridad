package com.example.demo.controller;

import com.example.demo.entity.User;
import com.example.demo.exception.UserNotFoundException;
import com.example.demo.repository.UserRepository;
import com.example.demo.web.UserDTO;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/users")
public class UserController {

    private final UserRepository userRepository;

    public UserController(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    /**
     * VULNERABLE (OWASP A02:2025): serializa la entidad y expone password y secretApiKey.
     * Una excepción no controlada también permite observar la mala configuración de errores.
     */
    @GetMapping("/vulnerable/{id}")
    public User getVulnerableUser(@PathVariable Long id) {
        return userRepository.findById(id)
                .orElseThrow(() -> new RuntimeException(
                        "Error interno al buscar el usuario con ID: " + id));
    }

    /** Mitigado: devuelve una representación pública y usa un error controlado. */
    @GetMapping("/mitigated/{id}")
    public ResponseEntity<UserDTO> getMitigatedUser(@PathVariable Long id) {
        User user = userRepository.findById(id)
                .orElseThrow(() -> new UserNotFoundException(
                        "El usuario con ID " + id + " no fue encontrado."));

        return ResponseEntity.ok(UserDTO.fromEntity(user));
    }
}