package com.example.demo.service;

import com.example.demo.entity.SoftwareComponent;
import com.example.demo.repository.SoftwareComponentRepository;
import com.example.demo.web.ComponentRequest;
import com.example.demo.web.ValidationResponse;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Set;

@Service
public class SoftwareSupplyChainService {

    private static final Set<String> TRUSTED_SUPPLIERS = Set.of("acme", "contoso", "example-corp");
    private static final Set<String> TRUSTED_DOMAINS = Set.of(
            "https://repo.example.com/",
            "https://cdn.example.com/",
            "https://artifacts.example.org/"
    );

    private final SoftwareComponentRepository repository;

    public SoftwareSupplyChainService(SoftwareComponentRepository repository) {
        this.repository = repository;
    }

    public ValidationResponse processVulnerableIngestion(ComponentRequest request) {
        if (request == null) {
            return new ValidationResponse(false, "La petición no puede estar vacía.");
        }

        SoftwareComponent component = new SoftwareComponent(
                request.getName(),
                request.getVersion(),
                request.getSupplier(),
                request.getSourceUrl(),
                request.getSha256(),
                request.getExpectedSha256(),
                "ACCEPTED_WITHOUT_VALIDATION");

        repository.save(component);

        return new ValidationResponse(true,
                "Componente aceptado sin validar proveedor ni hash SHA-256. Esto es vulnerable a Fallos en la Cadena de Suministro de Software.");
    }

    public ValidationResponse processMitigatedIngestion(ComponentRequest request) {
        if (request == null) {
            return new ValidationResponse(false, "La petición no puede estar vacía.");
        }

        String supplier = normalize(request.getSupplier());
        String sourceUrl = normalize(request.getSourceUrl());
        String providedHash = normalize(request.getSha256());
        String expectedHash = normalize(request.getExpectedSha256());

        if (!TRUSTED_SUPPLIERS.contains(supplier)) {
            return new ValidationResponse(false,
                    "Proveedor no autorizado. La ingesta fue rechazada porque no está en la lista blanca de proveedores confiables.");
        }

        if (!isTrustedOrigin(sourceUrl)) {
            return new ValidationResponse(false,
                    "Origen no autorizado. Solo se aceptan URLs oficiales de proveedores confiables.");
        }

        if (providedHash == null || expectedHash == null || !providedHash.equals(expectedHash)) {
            return new ValidationResponse(false,
                    "Hash SHA-256 inválido o no coincide con el valor esperado. La integridad del componente no fue validada.");
        }

        SoftwareComponent component = new SoftwareComponent(
                request.getName(),
                request.getVersion(),
                request.getSupplier(),
                request.getSourceUrl(),
                request.getSha256(),
                request.getExpectedSha256(),
                "VALIDATED");

        repository.save(component);

        return new ValidationResponse(true,
                "Componente validado correctamente: proveedor autorizado, dominio confiable y hash SHA-256 coincidente.");
    }

    public List<SoftwareComponent> getAllComponents() {
        return repository.findAll();
    }

    public void clearAll() {
        repository.deleteAll();
    }

    private boolean isTrustedOrigin(String sourceUrl) {
        if (sourceUrl == null || sourceUrl.isBlank()) {
            return false;
        }

        for (String trustedDomain : TRUSTED_DOMAINS) {
            if (sourceUrl.startsWith(trustedDomain)) {
                return true;
            }
        }

        return false;
    }

    private String normalize(String value) {
        if (value == null) {
            return null;
        }
        String normalized = value.trim();
        return normalized.isEmpty() ? null : normalized.toLowerCase();
    }
}
