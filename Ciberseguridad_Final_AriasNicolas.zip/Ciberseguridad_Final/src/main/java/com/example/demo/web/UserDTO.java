package com.example.demo.web;

import com.example.demo.entity.User;

public record UserDTO(Long id, String username, String email, String role) {

    public static UserDTO fromEntity(User user) {
        return new UserDTO(user.getId(), user.getUsername(), user.getEmail(), user.getRole());
    }
}