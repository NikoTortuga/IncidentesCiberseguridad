package com.example.demo.controller;

import com.example.demo.entity.Invoice;
import com.example.demo.service.InvoiceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/invoices")
public class InvoiceController {

    @Autowired
    private InvoiceService invoiceService;

    /**
     * VULNERABLE (OWASP A01:2025 - IDOR)
     * Ejemplo de prueba: GET /api/invoices/vulnerable/1 con header "X-User-Name: jorge_user"
     * Devuelve la factura #1 perteneciente a "eri_dev", vulnerando el control de acceso.
     */
    @GetMapping("/vulnerable/{id}")
    public ResponseEntity<Invoice> getVulnerable(
            @PathVariable Long id,
            @RequestHeader(value = "X-User-Name", defaultValue = "guest") String currentUser) {
        
        return ResponseEntity.ok(invoiceService.getInvoiceByIdUnsafe(id));
    }

    /**
     * SEGURO (Mitigado)
     * Ejemplo de prueba: GET /api/invoices/secure/1 con header "X-User-Name: jorge_user"
     * Devuelve HTTP 403 Forbidden porque "jorge_user" no es el propietario registrado.
     */
    @GetMapping("/secure/{id}")
    public ResponseEntity<Invoice> getSecure(
            @PathVariable Long id,
            @RequestHeader(value = "X-User-Name", defaultValue = "guest") String currentUser) {

        return ResponseEntity.ok(invoiceService.getInvoiceByIdSecure(id, currentUser));
    }
}
