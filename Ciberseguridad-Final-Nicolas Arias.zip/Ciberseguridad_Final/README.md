# Demo de vulnerabilidades OWASP

Esta aplicación es una demo pequeña para probar tres problemas de seguridad en una API REST. La idea no es construir un sistema de facturación real, sino poder comparar rápidamente qué ocurre cuando un endpoint no valida los datos y qué cambia al aplicar una mitigación.

El proyecto está hecho con **Spring Boot 3.2.5**, **Java 17**, Spring Data JPA y MySQL. Los endpoints se pueden probar con Postman, `curl` o la página incluida en `src/main/resources/static/index.html`.

## Qué incluye la demo

| Tema | Qué se muestra | Mitigación |
| --- | --- | --- |
| OWASP A01: Broken Access Control | Un usuario puede consultar una factura ajena cambiando el ID. | Comprobar que el usuario sea el propietario de la factura. |
| OWASP A02: Security Misconfiguration | La API devuelve secretos y muestra información interna en los errores. | Usar DTOs públicos y respuestas de error controladas. |
| OWASP A03: Software Supply Chain Failures | Se registra un componente sin comprobar su procedencia ni su hash. | Validar proveedor, dominio y SHA-256. |

Los endpoints vulnerables existen a propósito. No deben copiarse tal cual a una aplicación real.

## Matriz de causa y mitigación

| Incidente | Causa raíz en la versión vulnerable | Medida aplicada en la versión mitigada |
| --- | --- | --- |
| A01 - Broken Access Control | `InvoiceController` obtiene la factura por ID sin relacionar la petición con su propietario. | `InvoiceService` compara `X-User-Name` con `ownerUsername` y devuelve `403` si no coinciden. |
| A02 - Security Misconfiguration | `UserController` serializa la entidad completa y `server.error.include-stacktrace=always` deja expuesta información interna. | `UserDTO` excluye secretos y `GlobalExceptionHandler` genera un `ProblemDetail` con `404`, sin traza. |
| A03 - Software Supply Chain Failures | El endpoint vulnerable guarda el componente sin revisar proveedor, origen ni integridad. | `SoftwareSupplyChainService` usa listas blancas y compara los hashes antes de guardar el componente. |

## Preparar y ejecutar el proyecto

### Requisitos

- Java 17 o una versión posterior.
- Maven.
- MySQL Server iniciado.

La configuración de conexión está en [src/main/resources/application.properties](src/main/resources/application.properties). Por defecto usa:

```text
Base de datos: invoicedb
Usuario: root
Contraseña: 1234
Puerto de la aplicación: 8080
```

La configuración admite variables de entorno para no dejar las credenciales escritas en el entorno de ejecución: `DB_URL`, `DB_USERNAME`, `DB_PASSWORD` y `SERVER_PORT`. Si no se definen, se utilizan los valores anteriores para facilitar la práctica. La base de datos se crea automáticamente si no existe y `data.sql` carga los datos iniciales.

Para arrancar la aplicación:

```bash
mvn spring-boot:run
```

También se puede generar y ejecutar el JAR:

```bash
mvn clean package
java -jar target/demo-0.0.1-SNAPSHOT.jar
```

Si el puerto `8080` está ocupado, se puede iniciar la aplicación en otro puerto sin modificar el código:

```bash
mvn spring-boot:run -Dspring-boot.run.arguments="--server.port=8081"
```

## A01: Broken Access Control e IDOR

Una vulnerabilidad IDOR aparece cuando el servidor confía en el identificador que recibe, pero no comprueba si la persona que hace la petición tiene permiso para ver ese recurso.

En esta demo hay dos facturas:

- Factura `1`: pertenece a `eri_dev`.
- Factura `2`: pertenece a `jorge_user`.

### Endpoint vulnerable

```http
GET /api/invoices/vulnerable/{id}
```

El header `X-User-Name` se recibe, pero el endpoint vulnerable no lo utiliza para comprobar la propiedad de la factura. Por ejemplo, `jorge_user` puede consultar la factura de `eri_dev`:

```bash
curl http://localhost:8080/api/invoices/vulnerable/1 \
  -H "X-User-Name: jorge_user"
```

La respuesta es `200 OK` y contiene la factura 1. Ese es el problema: basta con cambiar el número del ID para consultar otro registro.

### Endpoint mitigado

```http
GET /api/invoices/secure/{id}
```

Este endpoint compara `X-User-Name` con `ownerUsername`. Si no coinciden, devuelve `403 Forbidden`:

```bash
curl http://localhost:8080/api/invoices/secure/1 \
  -H "X-User-Name: jorge_user"
```

Para probar el acceso correcto hay que enviar exactamente el usuario guardado en la factura. En este caso es `eri_dev`, no `eri_user`:

```bash
curl http://localhost:8080/api/invoices/secure/1 \
  -H "X-User-Name: eri_dev"
```

También existen las rutas equivalentes `/api/vulnerable/invoices/{id}` y `/api/mitigated/invoices/{id}`.

## A02: Security Misconfiguration

Esta parte muestra dos problemas de configuración y diseño que suelen aparecer juntos: devolver directamente una entidad de base de datos desde un controlador y dejar activada la información detallada de los errores. Como `User` contiene campos internos, la respuesta vulnerable expone `password` y `secretApiKey`. Además, `server.error.include-stacktrace=always` hace que una excepción no controlada pueda revelar la traza del servidor.

### Endpoint vulnerable

```bash
curl http://localhost:8080/api/users/vulnerable/1
```

La respuesta incluye todos los campos serializables del usuario, incluidos los que no deberían salir de la API.

### Endpoint mitigado

```bash
curl http://localhost:8080/api/users/mitigated/1
```

La respuesta usa `UserDTO` y solo expone información pública, como `id`, `username`, `email` y `role`. La solución no consiste en ocultar los campos desde el frontend, sino en no enviarlos desde el backend.

También se puede comparar el comportamiento con un usuario inexistente:

```bash
curl http://localhost:8080/api/vulnerable/users/999
curl http://localhost:8080/api/mitigated/users/999
```

La primera ruta responde `500` y puede incluir la traza porque representa el caso vulnerable. La segunda responde `404` con un `ProblemDetail` controlado y sin `RuntimeException` ni `stacktrace`.

## A03: Software Supply Chain Failures

La tercera parte simula el registro de un componente de software, por ejemplo una dependencia descargada desde un repositorio externo. El endpoint vulnerable acepta cualquier valor; el mitigado comprueba que el componente proceda de una fuente permitida y que el hash recibido coincida con el hash esperado.

### Registro sin validación

```bash
curl -X POST http://localhost:8080/api/components/vulnerable \
  -H "Content-Type: application/json" \
  -d '{
    "name": "openssl",
    "version": "3.2.0",
    "supplier": "evil-registry",
    "sourceUrl": "https://evil.example.net/download/openssl.tgz",
    "sha256": "abc123",
    "expectedSha256": "def456"
  }'
```

Aunque los datos no sean confiables, este endpoint responde `200 OK` y registra el componente.

### Registro con validación

```bash
curl -X POST http://localhost:8080/api/components/mitigated \
  -H "Content-Type: application/json" \
  -d '{
    "name": "openssl",
    "version": "3.2.0",
    "supplier": "acme",
    "sourceUrl": "https://repo.example.com/artifacts/openssl-3.2.0.tgz",
    "sha256": "a1b2c3d4e5f6",
    "expectedSha256": "a1b2c3d4e5f6"
  }'
```

Cuando el proveedor, el dominio y los dos hashes son válidos, la respuesta es `200 OK`. Si falla alguna comprobación, la respuesta es `400 Bad Request`.

Para revisar o limpiar los componentes registrados:

```http
GET    /api/components
DELETE /api/components
```

## Ejecutar las pruebas

Las pruebas de los controladores están en `src/test/java/com/example/demo`. Se pueden ejecutar con:

```bash
mvn test
```

Durante las pruebas se utiliza la configuración de test y H2, por lo que no hace falta modificar la base de datos de desarrollo. Los reportes generados por Maven quedan en `target/surefire-reports`.

## Estructura principal

```text
src/main/java/com/example/demo
├── controller/   Endpoints REST de las tres demostraciones
├── entity/       Entidades JPA
├── repository/   Acceso a la base de datos
├── service/      Reglas de negocio y validaciones
├── web/          DTOs y objetos de petición/respuesta
└── exception/    Excepciones y manejo global de errores
```

Los datos iniciales de las facturas y los usuarios están en [src/main/resources/data.sql](src/main/resources/data.sql). La aplicación también sirve una interfaz sencilla desde `http://localhost:8080/` cuando está en ejecución.

---

## Conclusión

El proyecto cumple con una presentación clara y ordenada de los casos:

- **A01**: acceso no autorizado a recursos por ID,
- **A02**: exposición de secretos y credenciales,
- **A03**: ingesta insegura de componentes con validación insuficiente.

Esto lo convierte en una demostración útil para explicar incidentes de ciberseguridad y las buenas prácticas asociadas a cada vulnerabilidad.
